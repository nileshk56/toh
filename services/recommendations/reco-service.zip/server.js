const express = require('express');
const config = require('./config');
const recoRoutes = require('./routes/recommendations');

const app = express();

app.use(express.json());
app.use('/recommendations', recoRoutes);

app.listen(config.port, () =>
  console.log(`Tags service running on ${config.port}`)
);